=======
Credits
=======

Development Lead
----------------

* Emmanuel Leblond `@touilleMan <https://github.com/touilleMan>`_

Godot Python logo
-----------------

* `@Pinswell <https://github.com/Pinswell>`_

Contributors
------------

* Răzvan Cosmin Rădulescu `@razvanc-r <https://github.com/razvanc-r>`_
* Max Hilbrunner `@mhilbrunner <https://github.com/mhilbrunner>`_
* Chris Ridenour `@cridenour <https://github.com/cridenour>`_
* Gary Oberbrunner `@garyo <https://github.com/garyo>`_
* Paolo Barresi `@paolobb4 <https://github.com/paolobb4>`_
* Colin Kinloch `@ColinKinloch <https://github.com/ColinKinloch>`_
