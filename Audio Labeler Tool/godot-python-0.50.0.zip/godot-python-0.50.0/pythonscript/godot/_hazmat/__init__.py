# `_hazmat` package containing all stuff not to be exposed to the user.
# Note we don't reexport anything in the `__init__.pxd` (i.e. this file)
# to avoid subtle recursive dependency errors within cython.
